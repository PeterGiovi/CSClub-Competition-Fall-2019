package com.company;

public class Main {

    public static void main(String[] args) {
        Stack s1 = new Stack(100);
        s1.toString();
        Stack s2 = new Stack(100, 100, 400);
        System.out.println();
        s2.toString();
    }
}
